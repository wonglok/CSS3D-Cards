console.log('\'Allo \'Allo!');

// var draggies = [];

// $('.card-group li').each(function(){
// 	var draggableElem = $(this)[0];
// 	var draggie = new Draggabilly( draggableElem, {

// 	});
// 	draggies.push( draggie );
// });



// setTimeout(function(){
// 	$('.card-container').toggleClass('arrived');
// }, 1000);
